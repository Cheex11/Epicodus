class Grid

  attr_reader :size, :spaces

  def initialize(size)
    @size = size
    @spaces = Array (0...(size*size))
  end

  def make_active(cells)
    cells.each do |cell|
      @spaces[cell] = '*'
    end
  end

  def remove_numbers
    spaces.map! do |cell|
      cell = (cell != '*' ? '-' : '*')
    end
  end

  def neighbor_check(cell_to_check)
    directions = {'N' => 'cell_to_check - @size', 'S' => 'cell_to_check + @size', 'E' => 'cell_to_check+1', 'W' => 'cell_to_check-1' }

  neighbor_count = 0

    directions.each do |key, value|
      if spaces[eval(value)] == "*"
        neighbor_count +=1
      else
        neighbor_count = neighbor_count
      end


    end

neighbor_count
      # cell + size (below)
      # cell - size (above)
      # cell + 1 (right)
      # cell - 1 (left)
      # cell + (size + 1) (diagonal down right)
      # cell - (size - 1) (diagonal up left)
      # cell - (size + 1) (diagonal up right)
      # cell + (size - 1) (diagonal down left)
      # cell


  end
end
